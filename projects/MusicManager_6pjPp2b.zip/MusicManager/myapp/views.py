from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.forms import AlbumForm,SongForm

from myapp.models import Album,Songs



class AlbumCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance = AlbumForm()

        qs = Album.objects.all()

        return render(request,"album_add.html",{"form":form_instance,"albums":qs})
    

    def post(self,request,*args,**kwargs):

        form_instance = AlbumForm(request.POST)

        if form_instance.is_valid():
            
            form_instance.save()

            return redirect("album-list")
        
        else:
            return render(request,"album_add.html",{"form":form_instance})



class AlbumListView(View):

    def get(self,request,*args,**kwargs):

        qs = Album.objects.all()

        return render(request,"album_list.html",{"list":qs})


class AlbumEditView(View):

    def get(self,request,*args,**kwargs):

        id = kwargs.get("pk")

        album_object = Album.objects.get(id=id)

        form_instance = AlbumForm(instance=album_object)

        return render(request,"album_edit.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        id = kwargs.get("pk")

        album_obj = Album.objects.get(id=id)

        form_instance = AlbumForm(request.POST,instance=album_obj)

        if form_instance.is_valid:

            form_instance.save()

            return redirect("album-add")

        return render(request,"album_edit.html",{"form":form_instance})
    
class AlbumDeleteView(View):

    def get(self,request,*args,**kwargs):

        id = kwargs.get("pk")

        Album.objects.get(id=id).delete()

        return redirect("album-add")
    



class SongCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance = SongForm()

        return render(request,"song_add.html",{"form":form_instance})
    

    def post(self,request,*args,**kwargs):

        form_instance = SongForm(request.POST)

        if form_instance.is_valid:

            form_instance.save()

            return redirect("song-list")
        
        return render(request,"song_add.html",{"form":form_instance})
    

class SongListView(View):

    def get(self,request,*args,**kwargs):

        qs = Songs.objects.all()

        return render(request,"song_list.html",{"list":qs})