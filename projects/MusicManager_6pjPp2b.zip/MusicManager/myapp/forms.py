from django import forms

from myapp.models import Album,Songs




class AlbumForm(forms.ModelForm):

    class Meta:

        model = Album
        fields = ["title","year","director","language"]

        widgets = {
            "title":forms.TextInput(attrs={"class":"form-control"}),
            "year":forms.NumberInput(attrs={"class":"form-control"}),
            "director":forms.TextInput(attrs={"class":"form-control"}),
            "language":forms.TextInput(attrs={"class":"form-control"})

        }


class SongForm(forms.ModelForm):

    class Meta:

        model = Songs

        fields = ["title","singer","track_number","album_object"]

        widgets = {
            "title":forms.TextInput(attrs={"class":"form-control"}),
            "singer":forms.TextInput(attrs={"class":"form-control"}),
            "track_number":forms.NumberInput(attrs={"class":"form-control"}),
            "album_object":forms.Select(attrs={"class":"form-control form-select"})
        }